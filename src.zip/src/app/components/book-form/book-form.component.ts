import { Component } from '@angular/core';
import { BookService } from '../../services/book.service';
import { inventoryData } from '../../context';

@Component({
  selector: 'app-book-form',
  templateUrl: './book-form.component.html',
  styleUrls: ['./book-form.component.css']
})
export class BookFormComponent {
  book: inventoryData = {
    bookID: 0,
    bookTitle: '',
    autherName: '',
    sellingPrice: 0,
    bookCatagory: ''
  };

  constructor(private bookService: BookService) {}

  addBook(): void {
    this.bookService.addBook(this.book).subscribe((response) => {
      console.log('Book added successfully!', response);
      alert('Book added successfully!');
    });
  }
}
