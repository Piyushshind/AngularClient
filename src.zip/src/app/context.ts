export class inventoryData {
    bookID: number = 0;
    bookTitle: String = "";

    autherName: String = "";
    sellingPrice: number = 0;

    bookCatagory: String = "";
} 