import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { inventoryData } from '../context';

@Injectable({
  providedIn: 'root',
})
export class BookService {
  private apiUrl = 'http://localhost:8056';  // Spring Boot URL

  constructor(private http: HttpClient) {}

  // Get all books
  getAllBooks(): Observable<inventoryData[]> {
    return this.http.get<inventoryData[]>(`${this.apiUrl}/showAll`);
  }

  // Add a new book
  addBook(book: inventoryData): Observable<inventoryData> {
    return this.http.post<inventoryData>(`${this.apiUrl}/insert`, book);
  }
}
